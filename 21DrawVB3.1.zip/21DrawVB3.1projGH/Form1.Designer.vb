﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.RadioButton21 = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown5 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown6 = New System.Windows.Forms.NumericUpDown()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.RadioButton20 = New System.Windows.Forms.RadioButton()
        Me.RadioButton19 = New System.Windows.Forms.RadioButton()
        Me.RadioButton17 = New System.Windows.Forms.RadioButton()
        Me.RadioButton14 = New System.Windows.Forms.RadioButton()
        Me.RadioButton13 = New System.Windows.Forms.RadioButton()
        Me.RadioButton12 = New System.Windows.Forms.RadioButton()
        Me.RadioButton11 = New System.Windows.Forms.RadioButton()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.RadioButton18 = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown4 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown3 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown2 = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton10 = New System.Windows.Forms.RadioButton()
        Me.RadioButton9 = New System.Windows.Forms.RadioButton()
        Me.RadioButton8 = New System.Windows.Forms.RadioButton()
        Me.RadioButton7 = New System.Windows.Forms.RadioButton()
        Me.RadioButton6 = New System.Windows.Forms.RadioButton()
        Me.RadioButton5 = New System.Windows.Forms.RadioButton()
        Me.RadioButton4 = New System.Windows.Forms.RadioButton()
        Me.RadioButton3 = New System.Windows.Forms.RadioButton()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.RadioButton23 = New System.Windows.Forms.RadioButton()
        Me.RadioButton22 = New System.Windows.Forms.RadioButton()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.ComboBox8 = New System.Windows.Forms.ComboBox()
        Me.ComboBox7 = New System.Windows.Forms.ComboBox()
        Me.ComboBox6 = New System.Windows.Forms.ComboBox()
        Me.ComboBox5 = New System.Windows.Forms.ComboBox()
        Me.ComboBox4 = New System.Windows.Forms.ComboBox()
        Me.RadioButton25 = New System.Windows.Forms.RadioButton()
        Me.RadioButton24 = New System.Windows.Forms.RadioButton()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.ComboBox12 = New System.Windows.Forms.ComboBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.ComboBox11 = New System.Windows.Forms.ComboBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.ComboBox10 = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.ComboBox9 = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.RadioButton27 = New System.Windows.Forms.RadioButton()
        Me.RadioButton26 = New System.Windows.Forms.RadioButton()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.RadioButton36 = New System.Windows.Forms.RadioButton()
        Me.RadioButton35 = New System.Windows.Forms.RadioButton()
        Me.RadioButton34 = New System.Windows.Forms.RadioButton()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.NumericUpDown7 = New System.Windows.Forms.NumericUpDown()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.RadioButton33 = New System.Windows.Forms.RadioButton()
        Me.RadioButton32 = New System.Windows.Forms.RadioButton()
        Me.RadioButton31 = New System.Windows.Forms.RadioButton()
        Me.RadioButton30 = New System.Windows.Forms.RadioButton()
        Me.RadioButton29 = New System.Windows.Forms.RadioButton()
        Me.RadioButton28 = New System.Windows.Forms.RadioButton()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.ComboBox21 = New System.Windows.Forms.ComboBox()
        Me.ComboBox20 = New System.Windows.Forms.ComboBox()
        Me.ComboBox19 = New System.Windows.Forms.ComboBox()
        Me.ComboBox18 = New System.Windows.Forms.ComboBox()
        Me.ComboBox17 = New System.Windows.Forms.ComboBox()
        Me.ComboBox16 = New System.Windows.Forms.ComboBox()
        Me.ComboBox15 = New System.Windows.Forms.ComboBox()
        Me.ComboBox14 = New System.Windows.Forms.ComboBox()
        Me.ComboBox13 = New System.Windows.Forms.ComboBox()
        Me.RadioButton40 = New System.Windows.Forms.RadioButton()
        Me.RadioButton39 = New System.Windows.Forms.RadioButton()
        Me.RadioButton38 = New System.Windows.Forms.RadioButton()
        Me.RadioButton37 = New System.Windows.Forms.RadioButton()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.RadioButton46 = New System.Windows.Forms.RadioButton()
        Me.NumericUpDown11 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown10 = New System.Windows.Forms.NumericUpDown()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.NumericUpDown9 = New System.Windows.Forms.NumericUpDown()
        Me.NumericUpDown8 = New System.Windows.Forms.NumericUpDown()
        Me.RadioButton45 = New System.Windows.Forms.RadioButton()
        Me.RadioButton16 = New System.Windows.Forms.RadioButton()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.RadioButton44 = New System.Windows.Forms.RadioButton()
        Me.RadioButton43 = New System.Windows.Forms.RadioButton()
        Me.RadioButton42 = New System.Windows.Forms.RadioButton()
        Me.RadioButton41 = New System.Windows.Forms.RadioButton()
        Me.RadioButton15 = New System.Windows.Forms.RadioButton()
        Me.ToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripButton2 = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripComboBox2 = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripComboBox3 = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripTextBox2 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripTextBox3 = New System.Windows.Forms.ToolStripTextBox()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OpenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DecorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PenLineColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Brush1ColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TextureBrushPictureToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GrBackColorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AllScreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SystemOfCoordinateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PastToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CopyScreenToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RotateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem()
        Me.FlipToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HorizontalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VerticalToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ServiceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutProgramToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripTextBox1 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripComboBox1 = New System.Windows.Forms.ToolStripComboBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FormatToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PointsControlToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PointsControlRelaxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripTextBox4 = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.NumericUpDown5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage1.SuspendLayout()
        CType(Me.NumericUpDown4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabControl1.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        CType(Me.NumericUpDown7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        CType(Me.NumericUpDown11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NumericUpDown8, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage9.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Location = New System.Drawing.Point(0, 108)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(1354, 353)
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "File Name"
        Me.OpenFileDialog1.Filter = resources.GetString("OpenFileDialog1.Filter")
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.FileName = "DrawVB"
        Me.SaveFileDialog1.Filter = resources.GetString("SaveFileDialog1.Filter")
        '
        'Timer1
        '
        Me.Timer1.Interval = 400
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.RadioButton21)
        Me.TabPage2.Controls.Add(Me.NumericUpDown5)
        Me.TabPage2.Controls.Add(Me.NumericUpDown6)
        Me.TabPage2.Controls.Add(Me.Label2)
        Me.TabPage2.Controls.Add(Me.RadioButton20)
        Me.TabPage2.Controls.Add(Me.RadioButton19)
        Me.TabPage2.Controls.Add(Me.RadioButton17)
        Me.TabPage2.Controls.Add(Me.RadioButton14)
        Me.TabPage2.Controls.Add(Me.RadioButton13)
        Me.TabPage2.Controls.Add(Me.RadioButton12)
        Me.TabPage2.Controls.Add(Me.RadioButton11)
        Me.TabPage2.Location = New System.Drawing.Point(4, 24)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1346, 28)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Next Items1"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'RadioButton21
        '
        Me.RadioButton21.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton21.AutoSize = True
        Me.RadioButton21.Location = New System.Drawing.Point(780, 1)
        Me.RadioButton21.Name = "RadioButton21"
        Me.RadioButton21.Size = New System.Drawing.Size(128, 25)
        Me.RadioButton21.TabIndex = 16
        Me.RadioButton21.TabStop = True
        Me.RadioButton21.Text = "Texture+GrBrushRect"
        Me.RadioButton21.UseVisualStyleBackColor = True
        '
        'NumericUpDown5
        '
        Me.NumericUpDown5.Location = New System.Drawing.Point(914, 3)
        Me.NumericUpDown5.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown5.Name = "NumericUpDown5"
        Me.NumericUpDown5.Size = New System.Drawing.Size(45, 23)
        Me.NumericUpDown5.TabIndex = 15
        Me.NumericUpDown5.Value = New Decimal(New Integer() {50, 0, 0, 0})
        '
        'NumericUpDown6
        '
        Me.NumericUpDown6.Location = New System.Drawing.Point(964, 2)
        Me.NumericUpDown6.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown6.Name = "NumericUpDown6"
        Me.NumericUpDown6.Size = New System.Drawing.Size(45, 23)
        Me.NumericUpDown6.TabIndex = 14
        Me.NumericUpDown6.Value = New Decimal(New Integer() {50, 0, 0, 0})
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(68, 6)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 15)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "C/Ang to It"
        '
        'RadioButton20
        '
        Me.RadioButton20.AutoSize = True
        Me.RadioButton20.Checked = True
        Me.RadioButton20.Location = New System.Drawing.Point(3, 6)
        Me.RadioButton20.Name = "RadioButton20"
        Me.RadioButton20.Size = New System.Drawing.Size(55, 19)
        Me.RadioButton20.TabIndex = 9
        Me.RadioButton20.TabStop = True
        Me.RadioButton20.Text = "St/Ch"
        Me.RadioButton20.UseVisualStyleBackColor = True
        '
        'RadioButton19
        '
        Me.RadioButton19.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton19.AutoSize = True
        Me.RadioButton19.Location = New System.Drawing.Point(1186, 1)
        Me.RadioButton19.Name = "RadioButton19"
        Me.RadioButton19.Size = New System.Drawing.Size(160, 25)
        Me.RadioButton19.TabIndex = 8
        Me.RadioButton19.Text = "Pen Line + Gr Bruch Cursor"
        Me.RadioButton19.UseVisualStyleBackColor = True
        '
        'RadioButton17
        '
        Me.RadioButton17.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton17.AutoSize = True
        Me.RadioButton17.Location = New System.Drawing.Point(666, 0)
        Me.RadioButton17.Name = "RadioButton17"
        Me.RadioButton17.Size = New System.Drawing.Size(112, 25)
        Me.RadioButton17.TabIndex = 7
        Me.RadioButton17.Text = "Texture Brush Any"
        Me.RadioButton17.UseVisualStyleBackColor = True
        '
        'RadioButton14
        '
        Me.RadioButton14.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton14.AutoSize = True
        Me.RadioButton14.Location = New System.Drawing.Point(444, 1)
        Me.RadioButton14.Name = "RadioButton14"
        Me.RadioButton14.Size = New System.Drawing.Size(124, 25)
        Me.RadioButton14.TabIndex = 4
        Me.RadioButton14.Text = "Brush with Gr Ellipse"
        Me.RadioButton14.UseVisualStyleBackColor = True
        '
        'RadioButton13
        '
        Me.RadioButton13.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton13.AutoSize = True
        Me.RadioButton13.Location = New System.Drawing.Point(328, 1)
        Me.RadioButton13.Name = "RadioButton13"
        Me.RadioButton13.Size = New System.Drawing.Size(114, 25)
        Me.RadioButton13.TabIndex = 3
        Me.RadioButton13.Text = "Brush with Gr Rect"
        Me.RadioButton13.UseVisualStyleBackColor = True
        '
        'RadioButton12
        '
        Me.RadioButton12.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton12.AutoSize = True
        Me.RadioButton12.Location = New System.Drawing.Point(228, 1)
        Me.RadioButton12.Name = "RadioButton12"
        Me.RadioButton12.Size = New System.Drawing.Size(98, 25)
        Me.RadioButton12.TabIndex = 2
        Me.RadioButton12.Text = "Gr Brush Ellipse"
        Me.RadioButton12.UseVisualStyleBackColor = True
        '
        'RadioButton11
        '
        Me.RadioButton11.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton11.AutoSize = True
        Me.RadioButton11.Location = New System.Drawing.Point(138, 1)
        Me.RadioButton11.Name = "RadioButton11"
        Me.RadioButton11.Size = New System.Drawing.Size(88, 25)
        Me.RadioButton11.TabIndex = 1
        Me.RadioButton11.Text = "Gr Brush Rect"
        Me.RadioButton11.UseVisualStyleBackColor = True
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.RadioButton18)
        Me.TabPage1.Controls.Add(Me.NumericUpDown4)
        Me.TabPage1.Controls.Add(Me.NumericUpDown3)
        Me.TabPage1.Controls.Add(Me.NumericUpDown2)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.NumericUpDown1)
        Me.TabPage1.Controls.Add(Me.RadioButton10)
        Me.TabPage1.Controls.Add(Me.RadioButton9)
        Me.TabPage1.Controls.Add(Me.RadioButton8)
        Me.TabPage1.Controls.Add(Me.RadioButton7)
        Me.TabPage1.Controls.Add(Me.RadioButton6)
        Me.TabPage1.Controls.Add(Me.RadioButton5)
        Me.TabPage1.Controls.Add(Me.RadioButton4)
        Me.TabPage1.Controls.Add(Me.RadioButton3)
        Me.TabPage1.Controls.Add(Me.RadioButton2)
        Me.TabPage1.Controls.Add(Me.RadioButton1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 24)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1346, 28)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Items"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'RadioButton18
        '
        Me.RadioButton18.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton18.AutoSize = True
        Me.RadioButton18.Location = New System.Drawing.Point(897, 1)
        Me.RadioButton18.Name = "RadioButton18"
        Me.RadioButton18.Size = New System.Drawing.Size(106, 25)
        Me.RadioButton18.TabIndex = 15
        Me.RadioButton18.TabStop = True
        Me.RadioButton18.Text = "Pen Line+Brush1"
        Me.RadioButton18.UseVisualStyleBackColor = True
        '
        'NumericUpDown4
        '
        Me.NumericUpDown4.Location = New System.Drawing.Point(1297, 2)
        Me.NumericUpDown4.Name = "NumericUpDown4"
        Me.NumericUpDown4.Size = New System.Drawing.Size(45, 23)
        Me.NumericUpDown4.TabIndex = 14
        Me.NumericUpDown4.Value = New Decimal(New Integer() {90, 0, 0, 0})
        '
        'NumericUpDown3
        '
        Me.NumericUpDown3.Location = New System.Drawing.Point(1248, 2)
        Me.NumericUpDown3.Name = "NumericUpDown3"
        Me.NumericUpDown3.Size = New System.Drawing.Size(45, 23)
        Me.NumericUpDown3.TabIndex = 13
        Me.NumericUpDown3.Value = New Decimal(New Integer() {50, 0, 0, 0})
        '
        'NumericUpDown2
        '
        Me.NumericUpDown2.Location = New System.Drawing.Point(1201, 2)
        Me.NumericUpDown2.Name = "NumericUpDown2"
        Me.NumericUpDown2.Size = New System.Drawing.Size(45, 23)
        Me.NumericUpDown2.TabIndex = 12
        Me.NumericUpDown2.Value = New Decimal(New Integer() {50, 0, 0, 0})
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(1050, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(125, 15)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Brushs Size W|H|Angle"
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Location = New System.Drawing.Point(1003, 2)
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(45, 23)
        Me.NumericUpDown1.TabIndex = 10
        '
        'RadioButton10
        '
        Me.RadioButton10.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton10.AutoSize = True
        Me.RadioButton10.Location = New System.Drawing.Point(817, 1)
        Me.RadioButton10.Name = "RadioButton10"
        Me.RadioButton10.Size = New System.Drawing.Size(80, 25)
        Me.RadioButton10.TabIndex = 9
        Me.RadioButton10.Text = "Brusg Fill Ell"
        Me.RadioButton10.UseVisualStyleBackColor = True
        '
        'RadioButton9
        '
        Me.RadioButton9.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton9.AutoSize = True
        Me.RadioButton9.Location = New System.Drawing.Point(724, 1)
        Me.RadioButton9.Name = "RadioButton9"
        Me.RadioButton9.Size = New System.Drawing.Size(91, 25)
        Me.RadioButton9.TabIndex = 8
        Me.RadioButton9.Text = "Brush Fill Rect"
        Me.RadioButton9.UseVisualStyleBackColor = True
        '
        'RadioButton8
        '
        Me.RadioButton8.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton8.AutoSize = True
        Me.RadioButton8.Location = New System.Drawing.Point(644, 1)
        Me.RadioButton8.Name = "RadioButton8"
        Me.RadioButton8.Size = New System.Drawing.Size(79, 25)
        Me.RadioButton8.TabIndex = 7
        Me.RadioButton8.Text = "Brush1 Rect"
        Me.RadioButton8.UseVisualStyleBackColor = True
        '
        'RadioButton7
        '
        Me.RadioButton7.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton7.AutoSize = True
        Me.RadioButton7.Location = New System.Drawing.Point(573, 1)
        Me.RadioButton7.Name = "RadioButton7"
        Me.RadioButton7.Size = New System.Drawing.Size(68, 25)
        Me.RadioButton7.TabIndex = 6
        Me.RadioButton7.Text = "Brush1 Ell"
        Me.RadioButton7.UseVisualStyleBackColor = True
        '
        'RadioButton6
        '
        Me.RadioButton6.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton6.AutoSize = True
        Me.RadioButton6.Location = New System.Drawing.Point(494, 1)
        Me.RadioButton6.Name = "RadioButton6"
        Me.RadioButton6.Size = New System.Drawing.Size(79, 25)
        Me.RadioButton6.TabIndex = 5
        Me.RadioButton6.Text = "PenL Ellipse"
        Me.RadioButton6.UseVisualStyleBackColor = True
        '
        'RadioButton5
        '
        Me.RadioButton5.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton5.AutoSize = True
        Me.RadioButton5.Location = New System.Drawing.Point(393, 1)
        Me.RadioButton5.Name = "RadioButton5"
        Me.RadioButton5.Size = New System.Drawing.Size(98, 25)
        Me.RadioButton5.TabIndex = 4
        Me.RadioButton5.Text = "PenL Rectangle"
        Me.RadioButton5.UseVisualStyleBackColor = True
        '
        'RadioButton4
        '
        Me.RadioButton4.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.Location = New System.Drawing.Point(295, 1)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(96, 25)
        Me.RadioButton4.TabIndex = 3
        Me.RadioButton4.Text = "PenL Right line"
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'RadioButton3
        '
        Me.RadioButton3.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Location = New System.Drawing.Point(192, 1)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(101, 25)
        Me.RadioButton3.TabIndex = 2
        Me.RadioButton3.Text = "PenL Some Line"
        Me.RadioButton3.UseVisualStyleBackColor = True
        '
        'RadioButton2
        '
        Me.RadioButton2.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(117, 1)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(73, 25)
        Me.RadioButton2.TabIndex = 1
        Me.RadioButton2.Text = "PenL Lines"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Checked = True
        Me.RadioButton1.Location = New System.Drawing.Point(5, 1)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(95, 19)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "Stop/Change"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Controls.Add(Me.TabPage6)
        Me.TabControl1.Controls.Add(Me.TabPage7)
        Me.TabControl1.Controls.Add(Me.TabPage8)
        Me.TabControl1.Controls.Add(Me.TabPage9)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Top
        Me.TabControl1.Location = New System.Drawing.Point(0, 52)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1354, 56)
        Me.TabControl1.TabIndex = 2
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.TextBox1)
        Me.TabPage3.Controls.Add(Me.Button2)
        Me.TabPage3.Controls.Add(Me.Button1)
        Me.TabPage3.Controls.Add(Me.ComboBox3)
        Me.TabPage3.Controls.Add(Me.ComboBox2)
        Me.TabPage3.Controls.Add(Me.ComboBox1)
        Me.TabPage3.Controls.Add(Me.RadioButton23)
        Me.TabPage3.Controls.Add(Me.RadioButton22)
        Me.TabPage3.Location = New System.Drawing.Point(4, 24)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(1346, 28)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Next Items2.Text."
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(591, 3)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(747, 23)
        Me.TextBox1.TabIndex = 8
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(550, 3)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(35, 23)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "E-R"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(515, 3)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(35, 23)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "R-E"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'ComboBox3
        '
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(364, 2)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(145, 23)
        Me.ComboBox3.TabIndex = 5
        '
        'ComboBox2
        '
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(313, 3)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(45, 23)
        Me.ComboBox2.TabIndex = 4
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Arial", "Bondoni MT", "Book Antiqua", "Bookman Old Style", "Calisto MT", "Castellar", "Century Gothic", "Century Schoolbook", "Comic Sans MS", "Courier", "Courier New", "Elephant", "Forte", "French Script MT", "Garamond", "Georgia", "Gigi", "Impact", "Kartika", "Latha", "Lucida Console", "Lucida Sans", "Mangal", "Marlett", "Microsoft Sans Serif", "MS Reference Sans Serif", "Palace Script MT", "Palatio Linotype", "Papurus", "Perpetua", "Rage Italic", "Rockwell", "Script MT Bold", "Symbol", "Tahoma", "Terminal", "Times New Roman", "Trebuchet MS", "Tunga", "Verdana", "Vrinda", "Webdings", "Wingdings"})
        Me.ComboBox1.Location = New System.Drawing.Point(163, 3)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(145, 23)
        Me.ComboBox1.TabIndex = 3
        '
        'RadioButton23
        '
        Me.RadioButton23.AutoSize = True
        Me.RadioButton23.Location = New System.Drawing.Point(111, 4)
        Me.RadioButton23.Name = "RadioButton23"
        Me.RadioButton23.Size = New System.Drawing.Size(46, 19)
        Me.RadioButton23.TabIndex = 2
        Me.RadioButton23.TabStop = True
        Me.RadioButton23.Text = "Text"
        Me.ToolTip1.SetToolTip(Me.RadioButton23, "Enter text in text window." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Click the button." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Clicl twice in the" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " drawing area" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " by left mouse button.")
        Me.RadioButton23.UseVisualStyleBackColor = True
        '
        'RadioButton22
        '
        Me.RadioButton22.AutoSize = True
        Me.RadioButton22.Checked = True
        Me.RadioButton22.Location = New System.Drawing.Point(3, 0)
        Me.RadioButton22.Name = "RadioButton22"
        Me.RadioButton22.Size = New System.Drawing.Size(95, 19)
        Me.RadioButton22.TabIndex = 1
        Me.RadioButton22.TabStop = True
        Me.RadioButton22.Text = "Stop/Change"
        Me.RadioButton22.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Label5)
        Me.TabPage4.Controls.Add(Me.Label4)
        Me.TabPage4.Controls.Add(Me.Label3)
        Me.TabPage4.Controls.Add(Me.ComboBox8)
        Me.TabPage4.Controls.Add(Me.ComboBox7)
        Me.TabPage4.Controls.Add(Me.ComboBox6)
        Me.TabPage4.Controls.Add(Me.ComboBox5)
        Me.TabPage4.Controls.Add(Me.ComboBox4)
        Me.TabPage4.Controls.Add(Me.RadioButton25)
        Me.TabPage4.Controls.Add(Me.RadioButton24)
        Me.TabPage4.Location = New System.Drawing.Point(4, 24)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(1346, 28)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "Next Items3. System of Coordinate."
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(829, 6)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(76, 15)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Width of Pen"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(522, 6)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(172, 15)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Number of sells: Width/Height."
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(282, 7)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(114, 15)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Width/Height of sell"
        '
        'ComboBox8
        '
        Me.ComboBox8.FormattingEnabled = True
        Me.ComboBox8.Location = New System.Drawing.Point(923, 2)
        Me.ComboBox8.Name = "ComboBox8"
        Me.ComboBox8.Size = New System.Drawing.Size(53, 23)
        Me.ComboBox8.TabIndex = 8
        '
        'ComboBox7
        '
        Me.ComboBox7.FormattingEnabled = True
        Me.ComboBox7.Location = New System.Drawing.Point(759, 3)
        Me.ComboBox7.Name = "ComboBox7"
        Me.ComboBox7.Size = New System.Drawing.Size(53, 23)
        Me.ComboBox7.TabIndex = 7
        '
        'ComboBox6
        '
        Me.ComboBox6.FormattingEnabled = True
        Me.ComboBox6.Location = New System.Drawing.Point(702, 3)
        Me.ComboBox6.Name = "ComboBox6"
        Me.ComboBox6.Size = New System.Drawing.Size(53, 23)
        Me.ComboBox6.TabIndex = 6
        '
        'ComboBox5
        '
        Me.ComboBox5.FormattingEnabled = True
        Me.ComboBox5.Location = New System.Drawing.Point(456, 4)
        Me.ComboBox5.Name = "ComboBox5"
        Me.ComboBox5.Size = New System.Drawing.Size(53, 23)
        Me.ComboBox5.TabIndex = 5
        '
        'ComboBox4
        '
        Me.ComboBox4.FormattingEnabled = True
        Me.ComboBox4.Location = New System.Drawing.Point(400, 4)
        Me.ComboBox4.Name = "ComboBox4"
        Me.ComboBox4.Size = New System.Drawing.Size(53, 23)
        Me.ComboBox4.TabIndex = 4
        '
        'RadioButton25
        '
        Me.RadioButton25.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton25.AutoSize = True
        Me.RadioButton25.Location = New System.Drawing.Point(110, 1)
        Me.RadioButton25.Name = "RadioButton25"
        Me.RadioButton25.Size = New System.Drawing.Size(131, 25)
        Me.RadioButton25.TabIndex = 3
        Me.RadioButton25.TabStop = True
        Me.RadioButton25.Text = "System Of coordinate"
        Me.RadioButton25.UseVisualStyleBackColor = True
        '
        'RadioButton24
        '
        Me.RadioButton24.AutoSize = True
        Me.RadioButton24.Checked = True
        Me.RadioButton24.Location = New System.Drawing.Point(3, 5)
        Me.RadioButton24.Name = "RadioButton24"
        Me.RadioButton24.Size = New System.Drawing.Size(95, 19)
        Me.RadioButton24.TabIndex = 2
        Me.RadioButton24.TabStop = True
        Me.RadioButton24.Text = "Stop/Change"
        Me.RadioButton24.UseVisualStyleBackColor = True
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.ComboBox12)
        Me.TabPage5.Controls.Add(Me.Label9)
        Me.TabPage5.Controls.Add(Me.ComboBox11)
        Me.TabPage5.Controls.Add(Me.Label8)
        Me.TabPage5.Controls.Add(Me.ComboBox10)
        Me.TabPage5.Controls.Add(Me.Label7)
        Me.TabPage5.Controls.Add(Me.ComboBox9)
        Me.TabPage5.Controls.Add(Me.Label6)
        Me.TabPage5.Controls.Add(Me.RadioButton27)
        Me.TabPage5.Controls.Add(Me.RadioButton26)
        Me.TabPage5.Location = New System.Drawing.Point(4, 24)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(1346, 28)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "Next Items4 Dash/Cap"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'ComboBox12
        '
        Me.ComboBox12.FormattingEnabled = True
        Me.ComboBox12.Location = New System.Drawing.Point(1051, 2)
        Me.ComboBox12.Name = "ComboBox12"
        Me.ComboBox12.Size = New System.Drawing.Size(145, 23)
        Me.ComboBox12.TabIndex = 12
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(987, 6)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(61, 15)
        Me.Label9.TabIndex = 11
        Me.Label9.Text = "Dash Style"
        '
        'ComboBox11
        '
        Me.ComboBox11.FormattingEnabled = True
        Me.ComboBox11.Location = New System.Drawing.Point(822, 2)
        Me.ComboBox11.Name = "ComboBox11"
        Me.ComboBox11.Size = New System.Drawing.Size(145, 23)
        Me.ComboBox11.TabIndex = 10
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(753, 7)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(57, 15)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Dash Cap"
        '
        'ComboBox10
        '
        Me.ComboBox10.FormattingEnabled = True
        Me.ComboBox10.Location = New System.Drawing.Point(601, 3)
        Me.ComboBox10.Name = "ComboBox10"
        Me.ComboBox10.Size = New System.Drawing.Size(145, 23)
        Me.ComboBox10.TabIndex = 8
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(542, 4)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(51, 15)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "End Cap"
        '
        'ComboBox9
        '
        Me.ComboBox9.FormattingEnabled = True
        Me.ComboBox9.Location = New System.Drawing.Point(370, 4)
        Me.ComboBox9.Name = "ComboBox9"
        Me.ComboBox9.Size = New System.Drawing.Size(145, 23)
        Me.ComboBox9.TabIndex = 6
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(292, 4)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(55, 15)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Start Cap"
        '
        'RadioButton27
        '
        Me.RadioButton27.AutoSize = True
        Me.RadioButton27.Location = New System.Drawing.Point(116, 4)
        Me.RadioButton27.Name = "RadioButton27"
        Me.RadioButton27.Size = New System.Drawing.Size(131, 19)
        Me.RadioButton27.TabIndex = 4
        Me.RadioButton27.TabStop = True
        Me.RadioButton27.Text = "Dash/Cap style lines"
        Me.RadioButton27.UseVisualStyleBackColor = True
        '
        'RadioButton26
        '
        Me.RadioButton26.AutoSize = True
        Me.RadioButton26.Checked = True
        Me.RadioButton26.Location = New System.Drawing.Point(4, 1)
        Me.RadioButton26.Name = "RadioButton26"
        Me.RadioButton26.Size = New System.Drawing.Size(95, 19)
        Me.RadioButton26.TabIndex = 3
        Me.RadioButton26.TabStop = True
        Me.RadioButton26.Text = "Stop/Change"
        Me.RadioButton26.UseVisualStyleBackColor = True
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.RadioButton36)
        Me.TabPage6.Controls.Add(Me.RadioButton35)
        Me.TabPage6.Controls.Add(Me.RadioButton34)
        Me.TabPage6.Controls.Add(Me.Label12)
        Me.TabPage6.Controls.Add(Me.Label11)
        Me.TabPage6.Controls.Add(Me.NumericUpDown7)
        Me.TabPage6.Controls.Add(Me.Label10)
        Me.TabPage6.Controls.Add(Me.RadioButton33)
        Me.TabPage6.Controls.Add(Me.RadioButton32)
        Me.TabPage6.Controls.Add(Me.RadioButton31)
        Me.TabPage6.Controls.Add(Me.RadioButton30)
        Me.TabPage6.Controls.Add(Me.RadioButton29)
        Me.TabPage6.Controls.Add(Me.RadioButton28)
        Me.TabPage6.Location = New System.Drawing.Point(4, 24)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(1346, 28)
        Me.TabPage6.TabIndex = 5
        Me.TabPage6.Text = "Next Items5"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'RadioButton36
        '
        Me.RadioButton36.AutoSize = True
        Me.RadioButton36.Location = New System.Drawing.Point(1252, 4)
        Me.RadioButton36.Name = "RadioButton36"
        Me.RadioButton36.Size = New System.Drawing.Size(90, 19)
        Me.RadioButton36.TabIndex = 15
        Me.RadioButton36.TabStop = True
        Me.RadioButton36.Text = "Dr Fill GR Pn"
        Me.RadioButton36.UseVisualStyleBackColor = True
        '
        'RadioButton35
        '
        Me.RadioButton35.AutoSize = True
        Me.RadioButton35.Location = New System.Drawing.Point(1155, 4)
        Me.RadioButton35.Name = "RadioButton35"
        Me.RadioButton35.Size = New System.Drawing.Size(87, 19)
        Me.RadioButton35.TabIndex = 14
        Me.RadioButton35.TabStop = True
        Me.RadioButton35.Text = "Draw Fill Pn"
        Me.RadioButton35.UseVisualStyleBackColor = True
        '
        'RadioButton34
        '
        Me.RadioButton34.AutoSize = True
        Me.RadioButton34.Location = New System.Drawing.Point(1046, 4)
        Me.RadioButton34.Name = "RadioButton34"
        Me.RadioButton34.Size = New System.Drawing.Size(99, 19)
        Me.RadioButton34.TabIndex = 13
        Me.RadioButton34.TabStop = True
        Me.RadioButton34.Text = "Draw Polygon"
        Me.RadioButton34.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(901, 5)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(138, 15)
        Me.Label12.TabIndex = 12
        Me.Label12.Text = "Pts of Gr 1:3||Color Brush"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(693, 6)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(77, 15)
        Me.Label11.TabIndex = 11
        Me.Label11.Text = "Decor /PL/B1"
        '
        'NumericUpDown7
        '
        Me.NumericUpDown7.Location = New System.Drawing.Point(499, 1)
        Me.NumericUpDown7.Name = "NumericUpDown7"
        Me.NumericUpDown7.Size = New System.Drawing.Size(50, 23)
        Me.NumericUpDown7.TabIndex = 10
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(416, 4)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(79, 15)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Curve tention"
        '
        'RadioButton33
        '
        Me.RadioButton33.AutoSize = True
        Me.RadioButton33.Location = New System.Drawing.Point(776, 4)
        Me.RadioButton33.Name = "RadioButton33"
        Me.RadioButton33.Size = New System.Drawing.Size(121, 19)
        Me.RadioButton33.TabIndex = 6
        Me.RadioButton33.TabStop = True
        Me.RadioButton33.Text = "Dr Fill Gr CL Curve"
        Me.RadioButton33.UseVisualStyleBackColor = True
        '
        'RadioButton32
        '
        Me.RadioButton32.AutoSize = True
        Me.RadioButton32.Location = New System.Drawing.Point(555, 3)
        Me.RadioButton32.Name = "RadioButton32"
        Me.RadioButton32.Size = New System.Drawing.Size(136, 19)
        Me.RadioButton32.TabIndex = 8
        Me.RadioButton32.TabStop = True
        Me.RadioButton32.Text = "Draw Fill Close Curve"
        Me.RadioButton32.UseVisualStyleBackColor = True
        '
        'RadioButton31
        '
        Me.RadioButton31.AutoSize = True
        Me.RadioButton31.Location = New System.Drawing.Point(296, 3)
        Me.RadioButton31.Name = "RadioButton31"
        Me.RadioButton31.Size = New System.Drawing.Size(118, 19)
        Me.RadioButton31.TabIndex = 7
        Me.RadioButton31.TabStop = True
        Me.RadioButton31.Text = "Draw Close Curve"
        Me.RadioButton31.UseVisualStyleBackColor = True
        '
        'RadioButton30
        '
        Me.RadioButton30.AutoSize = True
        Me.RadioButton30.Location = New System.Drawing.Point(201, 3)
        Me.RadioButton30.Name = "RadioButton30"
        Me.RadioButton30.Size = New System.Drawing.Size(86, 19)
        Me.RadioButton30.TabIndex = 6
        Me.RadioButton30.TabStop = True
        Me.RadioButton30.Text = "Draw Curve"
        Me.RadioButton30.UseVisualStyleBackColor = True
        '
        'RadioButton29
        '
        Me.RadioButton29.AutoSize = True
        Me.RadioButton29.Location = New System.Drawing.Point(105, 4)
        Me.RadioButton29.Name = "RadioButton29"
        Me.RadioButton29.Size = New System.Drawing.Size(86, 19)
        Me.RadioButton29.TabIndex = 5
        Me.RadioButton29.TabStop = True
        Me.RadioButton29.Text = "Draw Besier"
        Me.RadioButton29.UseVisualStyleBackColor = True
        '
        'RadioButton28
        '
        Me.RadioButton28.AutoSize = True
        Me.RadioButton28.Checked = True
        Me.RadioButton28.Location = New System.Drawing.Point(3, 1)
        Me.RadioButton28.Name = "RadioButton28"
        Me.RadioButton28.Size = New System.Drawing.Size(95, 19)
        Me.RadioButton28.TabIndex = 4
        Me.RadioButton28.TabStop = True
        Me.RadioButton28.Text = "Stop/Change"
        Me.RadioButton28.UseVisualStyleBackColor = True
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.ComboBox21)
        Me.TabPage7.Controls.Add(Me.ComboBox20)
        Me.TabPage7.Controls.Add(Me.ComboBox19)
        Me.TabPage7.Controls.Add(Me.ComboBox18)
        Me.TabPage7.Controls.Add(Me.ComboBox17)
        Me.TabPage7.Controls.Add(Me.ComboBox16)
        Me.TabPage7.Controls.Add(Me.ComboBox15)
        Me.TabPage7.Controls.Add(Me.ComboBox14)
        Me.TabPage7.Controls.Add(Me.ComboBox13)
        Me.TabPage7.Controls.Add(Me.RadioButton40)
        Me.TabPage7.Controls.Add(Me.RadioButton39)
        Me.TabPage7.Controls.Add(Me.RadioButton38)
        Me.TabPage7.Controls.Add(Me.RadioButton37)
        Me.TabPage7.Location = New System.Drawing.Point(4, 24)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Size = New System.Drawing.Size(1346, 28)
        Me.TabPage7.TabIndex = 6
        Me.TabPage7.Text = "Next Items6"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'ComboBox21
        '
        Me.ComboBox21.FormattingEnabled = True
        Me.ComboBox21.Location = New System.Drawing.Point(1222, 1)
        Me.ComboBox21.Name = "ComboBox21"
        Me.ComboBox21.Size = New System.Drawing.Size(121, 23)
        Me.ComboBox21.TabIndex = 17
        '
        'ComboBox20
        '
        Me.ComboBox20.FormattingEnabled = True
        Me.ComboBox20.Location = New System.Drawing.Point(1099, 2)
        Me.ComboBox20.Name = "ComboBox20"
        Me.ComboBox20.Size = New System.Drawing.Size(121, 23)
        Me.ComboBox20.TabIndex = 16
        '
        'ComboBox19
        '
        Me.ComboBox19.FormattingEnabled = True
        Me.ComboBox19.Location = New System.Drawing.Point(979, 2)
        Me.ComboBox19.Name = "ComboBox19"
        Me.ComboBox19.Size = New System.Drawing.Size(121, 23)
        Me.ComboBox19.TabIndex = 15
        '
        'ComboBox18
        '
        Me.ComboBox18.FormattingEnabled = True
        Me.ComboBox18.Location = New System.Drawing.Point(857, 3)
        Me.ComboBox18.Name = "ComboBox18"
        Me.ComboBox18.Size = New System.Drawing.Size(121, 23)
        Me.ComboBox18.TabIndex = 14
        '
        'ComboBox17
        '
        Me.ComboBox17.FormattingEnabled = True
        Me.ComboBox17.Location = New System.Drawing.Point(735, 3)
        Me.ComboBox17.Name = "ComboBox17"
        Me.ComboBox17.Size = New System.Drawing.Size(121, 23)
        Me.ComboBox17.TabIndex = 13
        '
        'ComboBox16
        '
        Me.ComboBox16.FormattingEnabled = True
        Me.ComboBox16.Location = New System.Drawing.Point(614, 3)
        Me.ComboBox16.Name = "ComboBox16"
        Me.ComboBox16.Size = New System.Drawing.Size(121, 23)
        Me.ComboBox16.TabIndex = 12
        '
        'ComboBox15
        '
        Me.ComboBox15.FormattingEnabled = True
        Me.ComboBox15.Location = New System.Drawing.Point(493, 2)
        Me.ComboBox15.Name = "ComboBox15"
        Me.ComboBox15.Size = New System.Drawing.Size(121, 23)
        Me.ComboBox15.TabIndex = 11
        '
        'ComboBox14
        '
        Me.ComboBox14.FormattingEnabled = True
        Me.ComboBox14.Location = New System.Drawing.Point(370, 2)
        Me.ComboBox14.Name = "ComboBox14"
        Me.ComboBox14.Size = New System.Drawing.Size(121, 23)
        Me.ComboBox14.TabIndex = 10
        '
        'ComboBox13
        '
        Me.ComboBox13.FormattingEnabled = True
        Me.ComboBox13.Location = New System.Drawing.Point(248, 2)
        Me.ComboBox13.Name = "ComboBox13"
        Me.ComboBox13.Size = New System.Drawing.Size(121, 23)
        Me.ComboBox13.TabIndex = 9
        '
        'RadioButton40
        '
        Me.RadioButton40.AutoSize = True
        Me.RadioButton40.Location = New System.Drawing.Point(187, 3)
        Me.RadioButton40.Name = "RadioButton40"
        Me.RadioButton40.Size = New System.Drawing.Size(58, 19)
        Me.RadioButton40.TabIndex = 8
        Me.RadioButton40.TabStop = True
        Me.RadioButton40.Text = "MP|10"
        Me.RadioButton40.UseVisualStyleBackColor = True
        '
        'RadioButton39
        '
        Me.RadioButton39.AutoSize = True
        Me.RadioButton39.Location = New System.Drawing.Point(127, 4)
        Me.RadioButton39.Name = "RadioButton39"
        Me.RadioButton39.Size = New System.Drawing.Size(52, 19)
        Me.RadioButton39.TabIndex = 7
        Me.RadioButton39.TabStop = True
        Me.RadioButton39.Text = "MP|7"
        Me.RadioButton39.UseVisualStyleBackColor = True
        '
        'RadioButton38
        '
        Me.RadioButton38.AutoSize = True
        Me.RadioButton38.Location = New System.Drawing.Point(65, 3)
        Me.RadioButton38.Name = "RadioButton38"
        Me.RadioButton38.Size = New System.Drawing.Size(52, 19)
        Me.RadioButton38.TabIndex = 6
        Me.RadioButton38.TabStop = True
        Me.RadioButton38.Text = "MP|3"
        Me.RadioButton38.UseVisualStyleBackColor = True
        '
        'RadioButton37
        '
        Me.RadioButton37.AutoSize = True
        Me.RadioButton37.Checked = True
        Me.RadioButton37.Location = New System.Drawing.Point(4, 3)
        Me.RadioButton37.Name = "RadioButton37"
        Me.RadioButton37.Size = New System.Drawing.Size(55, 19)
        Me.RadioButton37.TabIndex = 5
        Me.RadioButton37.TabStop = True
        Me.RadioButton37.Text = "St/Ch"
        Me.RadioButton37.UseVisualStyleBackColor = True
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.RadioButton46)
        Me.TabPage8.Controls.Add(Me.NumericUpDown11)
        Me.TabPage8.Controls.Add(Me.NumericUpDown10)
        Me.TabPage8.Controls.Add(Me.Label14)
        Me.TabPage8.Controls.Add(Me.Label13)
        Me.TabPage8.Controls.Add(Me.NumericUpDown9)
        Me.TabPage8.Controls.Add(Me.NumericUpDown8)
        Me.TabPage8.Controls.Add(Me.RadioButton45)
        Me.TabPage8.Controls.Add(Me.RadioButton16)
        Me.TabPage8.Controls.Add(Me.Button7)
        Me.TabPage8.Controls.Add(Me.Button6)
        Me.TabPage8.Controls.Add(Me.Button5)
        Me.TabPage8.Controls.Add(Me.Button4)
        Me.TabPage8.Controls.Add(Me.Button3)
        Me.TabPage8.Location = New System.Drawing.Point(4, 24)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Size = New System.Drawing.Size(1346, 28)
        Me.TabPage8.TabIndex = 7
        Me.TabPage8.Text = "Next Items7 Flip/Rptate"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'RadioButton46
        '
        Me.RadioButton46.AutoSize = True
        Me.RadioButton46.Location = New System.Drawing.Point(1178, 4)
        Me.RadioButton46.Name = "RadioButton46"
        Me.RadioButton46.Size = New System.Drawing.Size(163, 19)
        Me.RadioButton46.TabIndex = 13
        Me.RadioButton46.Text = "Past at click for mix colors"
        Me.RadioButton46.UseVisualStyleBackColor = True
        '
        'NumericUpDown11
        '
        Me.NumericUpDown11.Location = New System.Drawing.Point(1095, 0)
        Me.NumericUpDown11.Maximum = New Decimal(New Integer() {2000, 0, 0, 0})
        Me.NumericUpDown11.Name = "NumericUpDown11"
        Me.NumericUpDown11.Size = New System.Drawing.Size(74, 23)
        Me.NumericUpDown11.TabIndex = 12
        '
        'NumericUpDown10
        '
        Me.NumericUpDown10.Location = New System.Drawing.Point(1018, 0)
        Me.NumericUpDown10.Maximum = New Decimal(New Integer() {2000, 0, 0, 0})
        Me.NumericUpDown10.Name = "NumericUpDown10"
        Me.NumericUpDown10.Size = New System.Drawing.Size(74, 23)
        Me.NumericUpDown10.TabIndex = 11
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(980, 4)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(32, 15)
        Me.Label14.TabIndex = 10
        Me.Label14.Text = "W/H"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(654, 6)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(171, 15)
        Me.Label13.TabIndex = 9
        Me.Label13.Text = "Upper Left Coner of sourse rect"
        '
        'NumericUpDown9
        '
        Me.NumericUpDown9.Location = New System.Drawing.Point(907, 2)
        Me.NumericUpDown9.Maximum = New Decimal(New Integer() {1000, 0, 0, 0})
        Me.NumericUpDown9.Name = "NumericUpDown9"
        Me.NumericUpDown9.Size = New System.Drawing.Size(66, 23)
        Me.NumericUpDown9.TabIndex = 8
        '
        'NumericUpDown8
        '
        Me.NumericUpDown8.Location = New System.Drawing.Point(832, 2)
        Me.NumericUpDown8.Maximum = New Decimal(New Integer() {2000, 0, 0, 0})
        Me.NumericUpDown8.Name = "NumericUpDown8"
        Me.NumericUpDown8.Size = New System.Drawing.Size(74, 23)
        Me.NumericUpDown8.TabIndex = 7
        '
        'RadioButton45
        '
        Me.RadioButton45.AutoSize = True
        Me.RadioButton45.Location = New System.Drawing.Point(516, 4)
        Me.RadioButton45.Name = "RadioButton45"
        Me.RadioButton45.Size = New System.Drawing.Size(131, 19)
        Me.RadioButton45.TabIndex = 6
        Me.RadioButton45.Text = "RB+Didital numbers"
        Me.RadioButton45.UseVisualStyleBackColor = True
        '
        'RadioButton16
        '
        Me.RadioButton16.AutoSize = True
        Me.RadioButton16.Checked = True
        Me.RadioButton16.Location = New System.Drawing.Point(3, 6)
        Me.RadioButton16.Name = "RadioButton16"
        Me.RadioButton16.Size = New System.Drawing.Size(95, 19)
        Me.RadioButton16.TabIndex = 5
        Me.RadioButton16.TabStop = True
        Me.RadioButton16.Text = "Stop/Change"
        Me.RadioButton16.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(437, 2)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(75, 23)
        Me.Button7.TabIndex = 4
        Me.Button7.Text = "Flip Vertical"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(335, 2)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(100, 23)
        Me.Button6.TabIndex = 3
        Me.Button6.Text = "Flip Horizintal"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(256, 2)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 23)
        Me.Button5.TabIndex = 2
        Me.Button5.Text = "Rotate 270"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(178, 3)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 1
        Me.Button4.Text = "Rotate 180"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(101, 4)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 0
        Me.Button3.Text = "Rotate 90"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.RadioButton44)
        Me.TabPage9.Controls.Add(Me.RadioButton43)
        Me.TabPage9.Controls.Add(Me.RadioButton42)
        Me.TabPage9.Controls.Add(Me.RadioButton41)
        Me.TabPage9.Controls.Add(Me.RadioButton15)
        Me.TabPage9.Location = New System.Drawing.Point(4, 24)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Size = New System.Drawing.Size(1346, 28)
        Me.TabPage9.TabIndex = 8
        Me.TabPage9.Text = "Next Items8"
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'RadioButton44
        '
        Me.RadioButton44.Appearance = System.Windows.Forms.Appearance.Button
        Me.RadioButton44.AutoSize = True
        Me.RadioButton44.Location = New System.Drawing.Point(482, 1)
        Me.RadioButton44.Name = "RadioButton44"
        Me.RadioButton44.Size = New System.Drawing.Size(94, 25)
        Me.RadioButton44.TabIndex = 7
        Me.RadioButton44.Text = "Rubber Thread"
        Me.RadioButton44.UseVisualStyleBackColor = True
        '
        'RadioButton43
        '
        Me.RadioButton43.AutoSize = True
        Me.RadioButton43.Location = New System.Drawing.Point(360, 3)
        Me.RadioButton43.Name = "RadioButton43"
        Me.RadioButton43.Size = New System.Drawing.Size(103, 19)
        Me.RadioButton43.TabIndex = 3
        Me.RadioButton43.Text = "RadioButton43"
        Me.RadioButton43.UseVisualStyleBackColor = True
        '
        'RadioButton42
        '
        Me.RadioButton42.AutoSize = True
        Me.RadioButton42.Location = New System.Drawing.Point(242, 3)
        Me.RadioButton42.Name = "RadioButton42"
        Me.RadioButton42.Size = New System.Drawing.Size(103, 19)
        Me.RadioButton42.TabIndex = 2
        Me.RadioButton42.Text = "RadioButton42"
        Me.RadioButton42.UseVisualStyleBackColor = True
        '
        'RadioButton41
        '
        Me.RadioButton41.AutoSize = True
        Me.RadioButton41.Location = New System.Drawing.Point(118, 3)
        Me.RadioButton41.Name = "RadioButton41"
        Me.RadioButton41.Size = New System.Drawing.Size(103, 19)
        Me.RadioButton41.TabIndex = 1
        Me.RadioButton41.Text = "RadioButton41"
        Me.RadioButton41.UseVisualStyleBackColor = True
        '
        'RadioButton15
        '
        Me.RadioButton15.AutoSize = True
        Me.RadioButton15.Checked = True
        Me.RadioButton15.Location = New System.Drawing.Point(6, 4)
        Me.RadioButton15.Name = "RadioButton15"
        Me.RadioButton15.Size = New System.Drawing.Size(95, 19)
        Me.RadioButton15.TabIndex = 0
        Me.RadioButton15.TabStop = True
        Me.RadioButton15.Text = "Stop/Change"
        Me.RadioButton15.UseVisualStyleBackColor = True
        '
        'ToolStripButton1
        '
        Me.ToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton1.Image = CType(resources.GetObject("ToolStripButton1.Image"), System.Drawing.Image)
        Me.ToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton1.Name = "ToolStripButton1"
        Me.ToolStripButton1.Size = New System.Drawing.Size(52, 22)
        Me.ToolStripButton1.Text = "Opacity"
        '
        'ToolStripButton2
        '
        Me.ToolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.ToolStripButton2.Image = CType(resources.GetObject("ToolStripButton2.Image"), System.Drawing.Image)
        Me.ToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolStripButton2.Name = "ToolStripButton2"
        Me.ToolStripButton2.Size = New System.Drawing.Size(76, 22)
        Me.ToolStripButton2.Text = "Opacity -0%"
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(243, 22)
        Me.ToolStripLabel1.Text = "Color Brush E /R , Brush Fill R/E, Gr Brush R/E"
        '
        'ToolStripComboBox2
        '
        Me.ToolStripComboBox2.AutoSize = False
        Me.ToolStripComboBox2.Name = "ToolStripComboBox2"
        Me.ToolStripComboBox2.Size = New System.Drawing.Size(145, 23)
        '
        'ToolStripComboBox3
        '
        Me.ToolStripComboBox3.AutoSize = False
        Me.ToolStripComboBox3.Name = "ToolStripComboBox3"
        Me.ToolStripComboBox3.Size = New System.Drawing.Size(145, 23)
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripButton1, Me.ToolStripButton2, Me.ToolStripLabel1, Me.ToolStripSeparator1, Me.ToolStripComboBox2, Me.ToolStripSeparator2, Me.ToolStripComboBox3, Me.ToolStripSeparator3, Me.ToolStripTextBox2, Me.ToolStripTextBox3})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 27)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1354, 25)
        Me.ToolStrip1.TabIndex = 1
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripTextBox2
        '
        Me.ToolStripTextBox2.Name = "ToolStripTextBox2"
        Me.ToolStripTextBox2.Size = New System.Drawing.Size(150, 25)
        '
        'ToolStripTextBox3
        '
        Me.ToolStripTextBox3.Name = "ToolStripTextBox3"
        Me.ToolStripTextBox3.Size = New System.Drawing.Size(150, 25)
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewToolStripMenuItem, Me.OpenToolStripMenuItem, Me.SaveToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 23)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'NewToolStripMenuItem
        '
        Me.NewToolStripMenuItem.Name = "NewToolStripMenuItem"
        Me.NewToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.NewToolStripMenuItem.Text = "New"
        '
        'OpenToolStripMenuItem
        '
        Me.OpenToolStripMenuItem.Name = "OpenToolStripMenuItem"
        Me.OpenToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.OpenToolStripMenuItem.Text = "Open"
        '
        'SaveToolStripMenuItem
        '
        Me.SaveToolStripMenuItem.Name = "SaveToolStripMenuItem"
        Me.SaveToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.SaveToolStripMenuItem.Text = "Save"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(103, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'DecorToolStripMenuItem
        '
        Me.DecorToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PenLineColorToolStripMenuItem, Me.Brush1ColorToolStripMenuItem, Me.TextureBrushPictureToolStripMenuItem, Me.BackColorToolStripMenuItem, Me.GrBackColorToolStripMenuItem, Me.AllScreenToolStripMenuItem, Me.SystemOfCoordinateToolStripMenuItem})
        Me.DecorToolStripMenuItem.Name = "DecorToolStripMenuItem"
        Me.DecorToolStripMenuItem.Size = New System.Drawing.Size(50, 23)
        Me.DecorToolStripMenuItem.Text = "Decor"
        '
        'PenLineColorToolStripMenuItem
        '
        Me.PenLineColorToolStripMenuItem.Name = "PenLineColorToolStripMenuItem"
        Me.PenLineColorToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.PenLineColorToolStripMenuItem.Text = "Pen Line Color"
        '
        'Brush1ColorToolStripMenuItem
        '
        Me.Brush1ColorToolStripMenuItem.Name = "Brush1ColorToolStripMenuItem"
        Me.Brush1ColorToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.Brush1ColorToolStripMenuItem.Text = "Brush1 Color"
        '
        'TextureBrushPictureToolStripMenuItem
        '
        Me.TextureBrushPictureToolStripMenuItem.Name = "TextureBrushPictureToolStripMenuItem"
        Me.TextureBrushPictureToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.TextureBrushPictureToolStripMenuItem.Text = "Texture Brush Picture"
        '
        'BackColorToolStripMenuItem
        '
        Me.BackColorToolStripMenuItem.Name = "BackColorToolStripMenuItem"
        Me.BackColorToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.BackColorToolStripMenuItem.Text = "Back Color"
        '
        'GrBackColorToolStripMenuItem
        '
        Me.GrBackColorToolStripMenuItem.Name = "GrBackColorToolStripMenuItem"
        Me.GrBackColorToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.GrBackColorToolStripMenuItem.Text = "Gr Back Color"
        '
        'AllScreenToolStripMenuItem
        '
        Me.AllScreenToolStripMenuItem.Name = "AllScreenToolStripMenuItem"
        Me.AllScreenToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.AllScreenToolStripMenuItem.Text = "All  screen"
        '
        'SystemOfCoordinateToolStripMenuItem
        '
        Me.SystemOfCoordinateToolStripMenuItem.Name = "SystemOfCoordinateToolStripMenuItem"
        Me.SystemOfCoordinateToolStripMenuItem.Size = New System.Drawing.Size(190, 22)
        Me.SystemOfCoordinateToolStripMenuItem.Text = "System Of Coordinate"
        '
        'EditToolStripMenuItem
        '
        Me.EditToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CopyToolStripMenuItem, Me.PastToolStripMenuItem, Me.CopyScreenToolStripMenuItem, Me.RotateToolStripMenuItem, Me.FlipToolStripMenuItem})
        Me.EditToolStripMenuItem.Name = "EditToolStripMenuItem"
        Me.EditToolStripMenuItem.Size = New System.Drawing.Size(39, 23)
        Me.EditToolStripMenuItem.Text = "Edit"
        '
        'CopyToolStripMenuItem
        '
        Me.CopyToolStripMenuItem.Name = "CopyToolStripMenuItem"
        Me.CopyToolStripMenuItem.Size = New System.Drawing.Size(140, 22)
        Me.CopyToolStripMenuItem.Text = "Copy"
        '
        'PastToolStripMenuItem
        '
        Me.PastToolStripMenuItem.Name = "PastToolStripMenuItem"
        Me.PastToolStripMenuItem.Size = New System.Drawing.Size(140, 22)
        Me.PastToolStripMenuItem.Text = "Past"
        '
        'CopyScreenToolStripMenuItem
        '
        Me.CopyScreenToolStripMenuItem.Name = "CopyScreenToolStripMenuItem"
        Me.CopyScreenToolStripMenuItem.Size = New System.Drawing.Size(140, 22)
        Me.CopyScreenToolStripMenuItem.Text = "Copy Screen"
        '
        'RotateToolStripMenuItem
        '
        Me.RotateToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem2, Me.ToolStripMenuItem3, Me.ToolStripMenuItem4})
        Me.RotateToolStripMenuItem.Name = "RotateToolStripMenuItem"
        Me.RotateToolStripMenuItem.Size = New System.Drawing.Size(140, 22)
        Me.RotateToolStripMenuItem.Text = "Rotate"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(92, 22)
        Me.ToolStripMenuItem2.Text = "90"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(92, 22)
        Me.ToolStripMenuItem3.Text = "180"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(92, 22)
        Me.ToolStripMenuItem4.Text = "270"
        '
        'FlipToolStripMenuItem
        '
        Me.FlipToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HorizontalToolStripMenuItem, Me.VerticalToolStripMenuItem})
        Me.FlipToolStripMenuItem.Name = "FlipToolStripMenuItem"
        Me.FlipToolStripMenuItem.Size = New System.Drawing.Size(140, 22)
        Me.FlipToolStripMenuItem.Text = "Flip"
        '
        'HorizontalToolStripMenuItem
        '
        Me.HorizontalToolStripMenuItem.Name = "HorizontalToolStripMenuItem"
        Me.HorizontalToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.HorizontalToolStripMenuItem.Text = "Horizontal"
        '
        'VerticalToolStripMenuItem
        '
        Me.VerticalToolStripMenuItem.Name = "VerticalToolStripMenuItem"
        Me.VerticalToolStripMenuItem.Size = New System.Drawing.Size(129, 22)
        Me.VerticalToolStripMenuItem.Text = "Vertical"
        '
        'ServiceToolStripMenuItem
        '
        Me.ServiceToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InformationToolStripMenuItem, Me.AboutProgramToolStripMenuItem})
        Me.ServiceToolStripMenuItem.Name = "ServiceToolStripMenuItem"
        Me.ServiceToolStripMenuItem.Size = New System.Drawing.Size(56, 23)
        Me.ServiceToolStripMenuItem.Text = "Service"
        '
        'InformationToolStripMenuItem
        '
        Me.InformationToolStripMenuItem.Name = "InformationToolStripMenuItem"
        Me.InformationToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.InformationToolStripMenuItem.Text = "Information"
        '
        'AboutProgramToolStripMenuItem
        '
        Me.AboutProgramToolStripMenuItem.Name = "AboutProgramToolStripMenuItem"
        Me.AboutProgramToolStripMenuItem.Size = New System.Drawing.Size(156, 22)
        Me.AboutProgramToolStripMenuItem.Text = "About program"
        '
        'ToolStripTextBox1
        '
        Me.ToolStripTextBox1.Name = "ToolStripTextBox1"
        Me.ToolStripTextBox1.Size = New System.Drawing.Size(100, 23)
        Me.ToolStripTextBox1.Text = "Pen Line Width"
        '
        'ToolStripComboBox1
        '
        Me.ToolStripComboBox1.AutoSize = False
        Me.ToolStripComboBox1.Name = "ToolStripComboBox1"
        Me.ToolStripComboBox1.Size = New System.Drawing.Size(45, 23)
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.DecorToolStripMenuItem, Me.EditToolStripMenuItem, Me.ServiceToolStripMenuItem, Me.FormatToolStripMenuItem, Me.ToolStripTextBox1, Me.ToolStripComboBox1, Me.ToolStripTextBox4})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1354, 27)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FormatToolStripMenuItem
        '
        Me.FormatToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PointsControlToolStripMenuItem, Me.PointsControlRelaxToolStripMenuItem})
        Me.FormatToolStripMenuItem.Name = "FormatToolStripMenuItem"
        Me.FormatToolStripMenuItem.Size = New System.Drawing.Size(57, 23)
        Me.FormatToolStripMenuItem.Text = "Format"
        '
        'PointsControlToolStripMenuItem
        '
        Me.PointsControlToolStripMenuItem.Name = "PointsControlToolStripMenuItem"
        Me.PointsControlToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.PointsControlToolStripMenuItem.Text = "Points Control"
        '
        'PointsControlRelaxToolStripMenuItem
        '
        Me.PointsControlRelaxToolStripMenuItem.Name = "PointsControlRelaxToolStripMenuItem"
        Me.PointsControlRelaxToolStripMenuItem.Size = New System.Drawing.Size(181, 22)
        Me.PointsControlRelaxToolStripMenuItem.Text = "Points Control Relax"
        '
        'ToolStripTextBox4
        '
        Me.ToolStripTextBox4.Name = "ToolStripTextBox4"
        Me.ToolStripTextBox4.Size = New System.Drawing.Size(200, 23)
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1354, 461)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "DrawVB"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.NumericUpDown5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.NumericUpDown4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        CType(Me.NumericUpDown7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage7.PerformLayout()
        Me.TabPage8.ResumeLayout(False)
        Me.TabPage8.PerformLayout()
        CType(Me.NumericUpDown11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NumericUpDown8, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents SaveFileDialog1 As SaveFileDialog
    Friend WithEvents Timer1 As Timer
    Friend WithEvents ColorDialog1 As ColorDialog
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents RadioButton14 As RadioButton
    Friend WithEvents RadioButton13 As RadioButton
    Friend WithEvents RadioButton12 As RadioButton
    Friend WithEvents RadioButton11 As RadioButton
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents NumericUpDown4 As NumericUpDown
    Friend WithEvents NumericUpDown3 As NumericUpDown
    Friend WithEvents NumericUpDown2 As NumericUpDown
    Friend WithEvents Label1 As Label
    Friend WithEvents NumericUpDown1 As NumericUpDown
    Friend WithEvents RadioButton10 As RadioButton
    Friend WithEvents RadioButton9 As RadioButton
    Friend WithEvents RadioButton8 As RadioButton
    Friend WithEvents RadioButton7 As RadioButton
    Friend WithEvents RadioButton6 As RadioButton
    Friend WithEvents RadioButton5 As RadioButton
    Friend WithEvents RadioButton4 As RadioButton
    Friend WithEvents RadioButton3 As RadioButton
    Friend WithEvents RadioButton2 As RadioButton
    Friend WithEvents RadioButton1 As RadioButton
    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents ToolStripButton1 As ToolStripButton
    Friend WithEvents ToolStripButton2 As ToolStripButton
    Friend WithEvents ToolStripLabel1 As ToolStripLabel
    Friend WithEvents ToolStripComboBox2 As ToolStripComboBox
    Friend WithEvents ToolStripComboBox3 As ToolStripComboBox
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NewToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OpenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SaveToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents DecorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PenLineColorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Brush1ColorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BackColorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AllScreenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EditToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PastToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CopyScreenToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ServiceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents InformationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutProgramToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripTextBox1 As ToolStripTextBox
    Friend WithEvents ToolStripComboBox1 As ToolStripComboBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents RadioButton17 As RadioButton
    Friend WithEvents RadioButton18 As RadioButton
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents ToolStripTextBox2 As ToolStripTextBox
    Friend WithEvents ToolStripTextBox3 As ToolStripTextBox
    Friend WithEvents GrBackColorToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents RadioButton19 As RadioButton
    Friend WithEvents RadioButton20 As RadioButton
    Friend WithEvents Label2 As Label
    Friend WithEvents TextureBrushPictureToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NumericUpDown5 As NumericUpDown
    Friend WithEvents NumericUpDown6 As NumericUpDown
    Friend WithEvents RadioButton21 As RadioButton
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents ComboBox3 As ComboBox
    Friend WithEvents ComboBox2 As ComboBox
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents RadioButton23 As RadioButton
    Friend WithEvents RadioButton22 As RadioButton
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents RadioButton25 As RadioButton
    Friend WithEvents RadioButton24 As RadioButton
    Friend WithEvents SystemOfCoordinateToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ComboBox8 As ComboBox
    Friend WithEvents ComboBox7 As ComboBox
    Friend WithEvents ComboBox6 As ComboBox
    Friend WithEvents ComboBox5 As ComboBox
    Friend WithEvents ComboBox4 As ComboBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents ComboBox12 As ComboBox
    Friend WithEvents Label9 As Label
    Friend WithEvents ComboBox11 As ComboBox
    Friend WithEvents Label8 As Label
    Friend WithEvents ComboBox10 As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents ComboBox9 As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents RadioButton27 As RadioButton
    Friend WithEvents RadioButton26 As RadioButton
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents RadioButton36 As RadioButton
    Friend WithEvents RadioButton35 As RadioButton
    Friend WithEvents RadioButton34 As RadioButton
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents NumericUpDown7 As NumericUpDown
    Friend WithEvents Label10 As Label
    Friend WithEvents RadioButton33 As RadioButton
    Friend WithEvents RadioButton32 As RadioButton
    Friend WithEvents RadioButton31 As RadioButton
    Friend WithEvents RadioButton30 As RadioButton
    Friend WithEvents RadioButton29 As RadioButton
    Friend WithEvents RadioButton28 As RadioButton
    Friend WithEvents FormatToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PointsControlToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PointsControlRelaxToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents ComboBox21 As ComboBox
    Friend WithEvents ComboBox20 As ComboBox
    Friend WithEvents ComboBox19 As ComboBox
    Friend WithEvents ComboBox18 As ComboBox
    Friend WithEvents ComboBox17 As ComboBox
    Friend WithEvents ComboBox16 As ComboBox
    Friend WithEvents ComboBox15 As ComboBox
    Friend WithEvents ComboBox14 As ComboBox
    Friend WithEvents ComboBox13 As ComboBox
    Friend WithEvents RadioButton40 As RadioButton
    Friend WithEvents RadioButton39 As RadioButton
    Friend WithEvents RadioButton38 As RadioButton
    Friend WithEvents RadioButton37 As RadioButton
    Friend WithEvents TabPage8 As TabPage
    Friend WithEvents Button7 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents RotateToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As ToolStripMenuItem
    Friend WithEvents FlipToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HorizontalToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents VerticalToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TabPage9 As TabPage
    Friend WithEvents RadioButton44 As RadioButton
    Friend WithEvents RadioButton43 As RadioButton
    Friend WithEvents RadioButton42 As RadioButton
    Friend WithEvents RadioButton41 As RadioButton
    Friend WithEvents RadioButton15 As RadioButton
    Friend WithEvents ToolStripTextBox4 As ToolStripTextBox
    Friend WithEvents RadioButton45 As RadioButton
    Friend WithEvents RadioButton16 As RadioButton
    Friend WithEvents RadioButton46 As RadioButton
    Friend WithEvents NumericUpDown11 As NumericUpDown
    Friend WithEvents NumericUpDown10 As NumericUpDown
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents NumericUpDown9 As NumericUpDown
    Friend WithEvents NumericUpDown8 As NumericUpDown
End Class
