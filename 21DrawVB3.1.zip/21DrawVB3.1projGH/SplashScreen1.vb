﻿Public NotInheritable Class SplashScreen1

    Private ReadOnly Random As New Random



    'TODO: легко использовать эту форму в качестве заставки. Это можно сделать на вкладке "Приложение"
    '  конструктора проектов (пункт "Свойства" в меню "Проект").


    Private Sub SplashScreen1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Установить текст диалога во время выполнения в соответствии с информацией о сборке приложения.  

        'TODO: настроить сведения о сборке приложения в области "Приложение" диалогового окна 
        '  свойств проекта (в меню "Проект").

        Label1.Text = "Version 1 0 1 0 "

        Label2.Text = "֎Copyright © WareZ VK Provider 2021 This program was made by Karavaev V.G."
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick


        BackColor = Color.FromArgb(255, Random.Next(255), Random.Next(255))
        Label1.BackColor = Color.FromArgb(255, Random.Next(255), Random.Next(255))
        Label2.BackColor = Color.FromArgb(255, Random.Next(255), Random.Next(255))


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click



        Close()


    End Sub


End Class
